# CORRELAÇÃO

# Encontrando relacionamentos

Um grande aspecto do módulo Pandas é o método `corr()`que calcula a relação entre cada coluna em seu conjunto de dados.

Vamos verificar nos dados que estamos trabalhando.

```python
import pandas as pd

df = pd.read_csv('data.csv')
print(df.corr())

#Resultado:
          Duration     Pulse  Maxpulse  Calories
Duration  1.000000 -0.059452 -0.250033  0.344341
Pulse    -0.059452  1.000000  0.269672  0.481791
Maxpulse -0.250033  0.269672  1.000000  0.335392
Calories  0.344341  0.481791  0.335392  1.000000
```

**Nota:** O método `corr()` ignora colunas "não numéricas", então para dados nomeados, poderíamos por exemplo atribuir números para os nomes e fazer a correlação em seguida.

O Resultado é uma tabela com muitos números que representam o quão bem está o relacionamento entre duas colunas.

O número varia de -1 a 1.

- `1` significa que existe uma relação de 1 para 1 (uma correlação perfeita), e para este conjunto de dados, cada vez que um valor subiu na primeira coluna, o outro também subiu.
- `0,9` também é uma boa relação, e se você aumentar um valor, o outro provavelmente aumentará também.
- `-0,9` seria uma relação tão boa quanto 0,9, mas se você aumentar um valor, o outro provavelmente diminuirá.
- `0,2` significa NÃO um bom relacionamento, o que significa que se um valor subir não significa que o outro subirá.

**O que é uma boa correlação?** 

Depende do uso, mas acho que é seguro dizer que você precisa ter pelo menos `0.6`(ou `-0.6`) para considerar uma boa correlação.

### Correlação “Perfeita”:

Podemos ver que "Duration" e "Duration" receberam o número `1.000000`, o que faz sentido, cada coluna sempre tem uma relação perfeita consigo mesma.

### Boa correlação:

"Duração" e "Calorias" têm uma correlação de `0.922721`, que é muito boa, e podemos prever que quanto mais você treina, mais calorias você queima, e vice-versa: se você queima muitas calorias, você provavelmente teve um longo treino.

### Correlação ruim:

"Duration" e "Maxpulse" obtiveram uma correlação de `0.009403`, que é muito ruim, o que significa que não podemos prever o pulso máximo apenas observando a duração do treino e vice-versa.

Através da análise desses dados é possível extrair informações úteis para a tomada de decisão.