# LIMPEZA DE DADOS

A limpeza de dados significa corrigir dados ruins em seu conjunto de dados.

Dados incorretos podem ser:

- Células vazias
- Dados no formato errado
- Dados errados
- Duplicatas

Nosso conjunto de dados está nos exercícios, dentro da pasta chamada “pandas” e  chama-se “dirtydata.csv”.

O conjunto de dados contém:

- Células vazias ("Data" na linha 22 e "Calorias" nas linhas 18 e 28)
- Formato incorreto ("Data" na linha 26)
- Dados incorretos ("Duração" na linha 7)
- Duplicatas (linha 11 e 12).

### Remoção de linhas

Células vazias podem fornecer um resultado errado ao analisar dados. Uma maneira de lidar com células vazias é remover as linhas que contêm células vazias, isso geralmente é bom, pois os conjuntos de dados podem ser muito grandes e a remoção de algumas linhas não terá um grande impacto no resultado.

### Exemplo:

```python
import pandas as pd

df = pd.read_csv('data.csv')
new_df = df.dropna()
print(new_df.to_string())
#Observe no resultado que algumas linhas foram removidas (linha 18, 22 e 28).
#Essas linhas tinham células com valores vazios.
```

**Nota:** Por padrão, o método`dropna()` retorna um *novo* DataFrame e não altera o original.

**Nota:** O `(inplace = True)`irá garantir que o método NÃO retorne um *novo* DataFrame, mas removerá todas as duplicatas do DataFrame *original .*

### Exemplo:

Remova todas as linhas com valores NULL:

```python
import pandas as pd

df = pd.read_csv('data.csv')
df.dropna(inplace = True)
print(df.to_string())
```

**Nota:** Agora, o `dropna(inplace = True)`NÃO retornará um novo DataFrame, mas removerá todas as linhas contendo valores NULL do DataFrame original.

### Substituir valores vazios

Outra maneira de lidar com células vazias é inserir um *novo* valor.

Dessa forma, você não precisa excluir linhas inteiras apenas por causa de algumas células vazias.

O método `fillna()`nos permite substituir células vazias por um valor:

### Exemplo:

Substitua os valores NULL pelo número 130:

```python
import pandas as pd

df = pd.read_csv('data.csv')
df.fillna(130, inplace = True)
```

### Substituir apenas para colunas especificadas

O exemplo acima substitui todas as células vazias em todo o Data Frame.

Para substituir apenas valores vazios de uma coluna, especifique o *nome da coluna* para o DataFrame:

# Exemplo

Substitua os valores NULL nas colunas "Calorias" pelo número 130:

import pandas as pddf = pd.read_csv('data.csv')df["Calories"].fillna(130, inplace = True)

# Substituir usando média, mediana ou modo

Uma maneira comum de substituir células vazias é calcular o valor médio, mediano ou moda da coluna.

O Pandas usa os métodos `mean()` `median()`e `mode()`para calcular os respectivos valores para uma coluna especificada:

# Exemplo

Calcule a MÉDIA e substitua quaisquer valores vazios por ela:

import pandas as pddf = pd.read_csv('data.csv')x = df["Calories"].mean()df["Calories"].fillna(x, inplace = True)

**Média** = o valor médio (a soma de todos os valores dividido pelo número de valores).

# Exemplo

Calcule a MEDIAN e substitua quaisquer valores vazios por ela:

import pandas as pddf = pd.read_csv('data.csv')x = df["Calories"].median()df["Calories"].fillna(x, inplace = True)

**Mediana** = o valor no meio, depois de classificar todos os valores em ordem crescente.

# Exemplo

Calcule o MODO e substitua quaisquer valores vazios por ele:

```python
import pandas as pd

df = pd.read_csv('data.csv')
x = df["Calories"].mode()[0]
df["Calories"].fillna(x, inplace = True)
```

**Moda** = o valor que aparece com mais frequência.

## Dados errados

"Dados errados" não precisam ser "células vazias" ou "formato errado", pode apenas estar errado, como se alguém registrasse "199" em vez de "1,99".

Às vezes, você pode identificar dados errados observando o conjunto de dados, porque tem uma expectativa do que deveria ser.

Se você der uma olhada em nosso conjunto de dados, verá que na linha 7, a duração é 450, mas para todas as outras linhas a duração está entre 30 e 60.

Não precisa estar errado, mas levando em consideração que este é o conjunto de dados das sessões de treino de alguém, concluímos com o fato de que essa pessoa não treinou em 450 minutos.

## Substituindo valores

Uma maneira de corrigir valores errados é substituí-los por outra coisa, no nosso exemplo provavelmente é um erro de digitação, e o valor deve ser "45" em vez de "450", e poderíamos inserir "45" na linha 7.

### Exemplo:

```python
import pandas as pd

df = pd.read_csv('data.csv')
df.loc[7,'Duration'] = 45
print(df.to_string())
```

Para conjuntos de dados pequenos, você pode substituir os dados errados um por um, mas não para conjuntos de dados grandes.

Para substituir dados errados por conjuntos de dados maiores, você pode criar algumas regras, por exemplo, definir alguns limites para valores legais e substituir quaisquer valores que estejam fora dos limites.

### Exemplo:

```python
import pandas as pd

df = pd.read_csv('data.csv')
for x in df.index:
	if df.loc[x, "Duration"] > 120:
		df.loc[x, "Duration"] = 120
print(df.to_string())
```

## Removendo linhas

Outra maneira de lidar com dados errados é remover as linhas que contêm dados errados.

Dessa forma, você não precisa descobrir com o que substituí-los e há uma boa chance de não precisar deles para fazer suas análises.

```python
import pandas as pd

df = pd.read_csv('data.csv')
for x in df.index:
	if df.loc[x, "Duration"] > 120:
		df.drop(x, inplace = True)
print(df.to_string())
#lembre-se de incluir o argumento 'inplace = True' para fazer as alterações no objeto DataFrame original em vez de retornar uma cópia
```

## Descobrindo duplicatas

Linhas duplicadas são linhas que foram registradas mais de uma vez.

Ao dar uma olhada em nosso conjunto de dados, podemos supor que as linhas 11 e 12 são duplicadas.

Para descobrir duplicatas, podemos usar o método `duplicated()`, pois ele retorna valores booleanos para cada linha:

### Exemplo:

```python
import pandas as pd

df = pd.read_csv('data.csv')
print(df.duplicated())
```

## Removendo duplicatas

Para remover duplicatas, use o `drop_duplicates()`método.

### Exemplo:

```python
import pandas as pd

df = pd.read_csv('data.csv')
df.drop_duplicates(inplace = True)
print(df.to_string())

#Observe que a linha 12 foi removida do resultado
```

**Nota:** O `(inplace = True)`irá garantir que o método NÃO retorne um *novo* DataFrame, mas removerá todas as duplicatas do DataFrame *original .*

Todo esse conteúdo de dados pode ser usado para criar programas para conjuntos de dados conhecidos que rodem automaticamente, assim, uma vez criado, você pode por exemplo extrair o que é relevante de maneira extremamente rápida, além de utilizar bibliotecas que integrem sistemas como excel por exemplo. Vai da sua criatividade fazer da melhor maneira. Você pode acessar o banco de referência do pandas e verificar todas os métodos do módulo pandas.