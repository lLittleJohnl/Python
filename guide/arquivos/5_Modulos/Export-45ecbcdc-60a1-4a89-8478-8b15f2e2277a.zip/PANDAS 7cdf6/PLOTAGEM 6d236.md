# PLOTAGEM

Pandas usa o método `plot()` para criar diagramas, mas podemos usar o Pyplot, um submódulo da biblioteca Matplotlib para visualizar o diagrama na tela.

### Exemplo:

Importe pyplot do Matplotlib e visualize nosso DataFrame:

```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data.csv')
df.plot()
plt.show()
```

## Gráfico de dispersão

Especifique que você deseja um gráfico de dispersão com o argumento `kind`:`kind = 'scatter'`

Um gráfico de dispersão precisa de um eixo x e um eixo y.

No exemplo abaixo, usaremos "Duração" para o eixo x e "Calorias" para o eixo y.

Inclua os argumentos x e y assim:

```python
# x = 'Duration', y = 'Calories'
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data.csv')
df.plot(kind = 'scatter', x = 'Duration', y = 'Calories')
plt.show()
```

**Lembre-se:** no exemplo anterior, aprendemos que a correlação entre "Duração" e "Calorias" era `0.922721`, e concluímos com o fato de que maior duração significa mais calorias queimadas, agora olhando para gráfico de de dispersão, podemos visualizar exatamente esse comportamento.

Vamos criar outro gráfico de dispersão, onde há um relacionamento ruim entre as colunas, como "Duration" e "Maxpulse", com a correlação `0.009403`:

### Exemplo:

Um gráfico de dispersão onde não há relacionamento entre as colunas:

```python
import pandas as pd
import matplotlib.pyplot as plt

df = pd.read_csv('data.csv')
df.plot(kind = 'scatter', x = 'Duration', y = 'Maxpulse')
plt.show()
```

# Histograma

Use o argumento `kind` para especificar que você deseja um histograma:`kind = 'hist'`

Um histograma precisa de apenas uma coluna e nos mostra a frequência de cada intervalo, por exemplo, quantos treinos duraram entre 50 e 60 minutos?

No exemplo abaixo usaremos a coluna "Duração" para criar o histograma:

### Exemplo:

df["Duration"].plot(kind = 'hist')

**Nota:** O histograma nos diz que houve mais de 100 treinos que duraram entre 50 e 60 minutos.