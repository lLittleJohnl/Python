# MÉTODOS DE TUPLA

Python tem dois métodos integrados que você pode usar em tuplas.

**Método      Descrição**

**count(   )**      Retorna o número de vezes que um valor especificado ocorre em uma tupla
**index(   )**      Pesquisa a tupla por um valor especificado e retorna a posição de onde foi encontrado